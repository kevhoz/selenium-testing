<?php
require_once 'config.php';
header("Content-Type: application/json");

$data = json_decode(file_get_contents("php://input"), true);
$username = $data['username'] ?? '';
$password = $data['password'] ?? '';

$stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? AND password = ?");
$stmt->execute([$username, $password]);
$user = $stmt->fetch();

if ($user) {
    echo json_encode([
        "success" => true,
        "token" => "dummy-token"
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Login gagal"
    ]);
}
?>
