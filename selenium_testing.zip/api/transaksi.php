<?php
require_once 'config.php';
header("Content-Type: application/json");

$headers = getallheaders();
$auth = $headers['Authorization'] ?? '';

if ($auth !== 'dummy-token') {
    http_response_code(403);
    echo json_encode(["success" => false, "message" => "Unauthorized"]);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];

// GET - Ambil semua data
if ($method === 'GET') {
    $stmt = $pdo->query("SELECT * FROM transaksi ORDER BY id DESC");
    $data = $stmt->fetchAll();
    echo json_encode(["success" => true, "data" => $data]);
    exit;
}

// POST - Handle insert, update, delete
if ($method === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);
    $action = $data['action'] ?? '';

    if ($action === 'insert') {
        $nama_barang = $data['nama_barang'] ?? '';
        $jumlah = $data['jumlah'] ?? 0;
        $harga = $data['harga'] ?? 0;

        if ($nama_barang && $jumlah && $harga) {
            $stmt = $pdo->prepare("INSERT INTO transaksi (nama_barang, jumlah, harga) VALUES (?, ?, ?)");
            $stmt->execute([$nama_barang, $jumlah, $harga]);
            echo json_encode(["success" => true, "message" => "Berhasil disimpan"]);
        } else {
            echo json_encode(["success" => false, "message" => "Data tidak lengkap"]);
        }
        exit;
    }

    if ($action === 'update') {
        $id = $data['id'] ?? 0;
        $nama_barang = $data['nama_barang'] ?? '';
        $jumlah = $data['jumlah'] ?? 0;
        $harga = $data['harga'] ?? 0;

        if ($id && $nama_barang && $jumlah && $harga) {
            $stmt = $pdo->prepare("UPDATE transaksi SET nama_barang = ?, jumlah = ?, harga = ? WHERE id = ?");
            $stmt->execute([$nama_barang, $jumlah, $harga, $id]);
            echo json_encode(["success" => true, "message" => "Berhasil diupdate"]);
        } else {
            echo json_encode(["success" => false, "message" => "Data tidak lengkap untuk update"]);
        }
        exit;
    }

    if ($action === 'delete') {
        $id = $data['id'] ?? 0;
        if ($id) {
            $stmt = $pdo->prepare("DELETE FROM transaksi WHERE id = ?");
            $stmt->execute([$id]);
            echo json_encode(["success" => true, "message" => "Berhasil dihapus"]);
        } else {
            echo json_encode(["success" => false, "message" => "ID kosong"]);
        }
        exit;
    }
}

// Jika method tidak dikenali
echo json_encode(["success" => false, "message" => "Method not allowed"]);
