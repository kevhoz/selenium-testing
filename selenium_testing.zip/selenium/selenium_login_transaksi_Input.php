<?php
require 'vendor/autoload.php';

use Facebook\WebDriver\Remote\RemoteWebDriver;
use Facebook\WebDriver\Remote\DesiredCapabilities;
use Facebook\WebDriver\WebDriverBy;

$driver = RemoteWebDriver::create("http://localhost:4444/wd/hub", DesiredCapabilities::chrome());

// 1. Buka halaman login
$driver->get("http://localhost/selenium_test/index.html");

// 2. Login
$driver->findElement(WebDriverBy::id("username"))->sendKeys("user1");
$driver->findElement(WebDriverBy::id("password"))->sendKeys("password123");
$driver->findElement(WebDriverBy::xpath("//button[contains(text(),'Login')]"))->click();
sleep(2);

// 3. Isi form transaksi
$driver->findElement(WebDriverBy::id("nama_barang"))->sendKeys("Meja");
$driver->findElement(WebDriverBy::id("jumlah"))->sendKeys("1");
$driver->findElement(WebDriverBy::id("harga"))->sendKeys("100000");
$driver->findElement(WebDriverBy::xpath("//button[contains(text(),'Tambah')]"))->click();
sleep(2);

// 4. Verifikasi
$rows = $driver->findElements(WebDriverBy::tagName("tr"));
$found = false;
foreach ($rows as $row) {
    if (strpos($row->getText(), "Meja") !== false) {
        $found = true;
        break;
    }
}
echo $found ? "✅ Transaksi berhasil\n" : "❌ Gagal input\n";
$driver->quit();
?>
