CREATE DATABASE IF NOT EXISTS selenium_app;
USE selenium_app;

-- Tabel user
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL
);

-- Insert user dummy
INSERT INTO users (username, password) VALUES ('user1', 'password123');

-- Tabel transaksi
CREATE TABLE transaksi (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_barang VARCHAR(100),
    jumlah INT,
    harga INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
